package ru.job4j.cast;

public class College {
    public static void main(String[] args) {
        Freshman fresh = new Freshman();
        Student st = fresh;
        Object obj = fresh;
    }
}
