package ru.job4j.tracker;

public class Tiger extends Predator {
    public Tiger() {
        super();
    }

    public Tiger(String varConstructor) {
        super(varConstructor);
    }
}
