package ru.job4j.cast;

public class Object {
}
