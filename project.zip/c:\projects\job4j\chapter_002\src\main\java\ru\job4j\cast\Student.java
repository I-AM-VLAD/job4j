package ru.job4j.cast;

public class Student extends Object {
}
