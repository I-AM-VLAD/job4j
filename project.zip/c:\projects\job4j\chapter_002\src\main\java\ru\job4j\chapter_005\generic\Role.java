package ru.job4j.chapter_005.generic;

public class Role extends Base{

    public Role(final String id) {
        super(id);
    }

    public String getId() {
        return super.getId();
    }
}
