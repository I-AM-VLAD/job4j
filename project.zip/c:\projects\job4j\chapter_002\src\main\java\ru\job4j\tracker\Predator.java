package ru.job4j.tracker;

public class Predator extends Animal {
    public Predator() {
        super();
    }

    public Predator(String varConstructor) {
        super(varConstructor);
    }
}