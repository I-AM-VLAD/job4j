/**
 * Package for calculate task.
 *
 * @author Vlad Chupryna (vlad1slaw19982@gmail.com)
 * @version $Id$
 * @since 04.01.2020
 */
package ru.job4j.calculator;