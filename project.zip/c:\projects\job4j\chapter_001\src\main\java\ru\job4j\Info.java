package ru.job4j;

public class Info {

}
