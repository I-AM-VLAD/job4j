package ru.job4j.cast;

public class Freshman extends Student{
}
